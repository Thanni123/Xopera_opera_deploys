package spblab.thumbgen.azure;

public class Config {
    public static final String STORAGE_ACCOUNT_NAME = "AzureWebJobsStorage";
}
